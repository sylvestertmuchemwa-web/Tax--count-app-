# Taxi Count — Test Prototype

A simple, mobile-friendly test page for a minibus taxi passenger counter.

## Features
- Passenger count (test capacity: 15)
- Confirm boarding and exit buttons
- Passenger waiting-status demo
- Example R15 fare recorder and shift total

## Run locally
Open `index.html` in a modern web browser.

## Important limitations
- This is only a front-end prototype.
- Data resets when the page is reloaded.
- Passenger status and counts are not shared between devices.
- No accounts, GPS tracking, backend, or real payment processing are included.
- Use test data only; do not enter real passenger or payment information.

## Publish with GitHub Pages
1. Upload `index.html` to the root of your GitHub repository.
2. Open repository Settings → Pages.
3. Under build/deployment, choose deploy from a branch.
4. Select the `main` branch and `/ (root)`, then save.
5. Wait for GitHub Pages to publish the site.
